This program runs SURLY-input.txt and creates a database out of the SQL statements in the text file.
In addition, the program runs through basic commands for demonstrational purpose. 

This file is ran through eclispe with no additional software installed. For proper sound, make sure sounds folder is located within the working directory of the application.
