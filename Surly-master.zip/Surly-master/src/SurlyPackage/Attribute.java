package SurlyPackage;

public class Attribute {
	String name;
	String displayType;
	String formatSpacing;

	public Attribute(String _name, String _dT, String _fS)
	{
		this.name = _name;
		this.displayType = _dT;
		this.formatSpacing = _fS;
	}

	
}
